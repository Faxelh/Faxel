package com.faxel.app.update

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import com.faxel.app.R
import java.io.File
import kotlin.math.min

/**
 * Nom de l'application choisi par l'utilisateur. Android ne laisse pas une app renommer
 * son icône installée : on enregistre le nom (utilisé dans l'app) et on pose sur l'écran
 * d'accueil une icône à ce nom (raccourci épinglé, renommé à chaque changement).
 */
object AppName {
    private const val SHORTCUT_ID = "app_name"

    private fun prefs(context: Context) = context.getSharedPreferences("app_name", Context.MODE_PRIVATE)

    fun default(context: Context): String = context.getString(R.string.app_name)

    fun get(context: Context): String =
        prefs(context).getString("name", null)?.trim()?.takeIf { it.isNotEmpty() } ?: default(context)

    fun set(context: Context, name: String) {
        val clean = name.trim().take(30)
        prefs(context).edit().putString("name", if (clean == default(context)) "" else clean).apply()
    }

    fun customIcon(context: Context): Bitmap? = prefs(context).getString("icon_path", null)
        ?.let { path -> BitmapFactory.decodeFile(path) }

    fun setCustomIcon(context: Context, uri: android.net.Uri?): Boolean {
        if (uri == null) {
            prefs(context).edit().remove("icon_path").apply()
            return true
        }
        return try {
            val source = context.contentResolver.openInputStream(uri)?.use { stream -> BitmapFactory.decodeStream(stream) } ?: return false
            val side = min(source.width, source.height)
            val square = Bitmap.createBitmap(source, (source.width - side) / 2, (source.height - side) / 2, side, side)
            val scaled = Bitmap.createScaledBitmap(square, 512, 512, true)
            val file = File(context.filesDir, "faxel-home-icon.png")
            file.outputStream().use { scaled.compress(Bitmap.CompressFormat.PNG, 100, it) }
            prefs(context).edit().putString("icon_path", file.absolutePath).apply()
            true
        } catch (_: Exception) { false }
    }

    /** Pose (ou renomme) l'icône « nom » sur l'écran d'accueil. Faux si le lanceur ne le permet pas. */
    fun pinShortcut(context: Context, name: String, request: Boolean = true): Boolean {
        val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
            ?.apply { action = Intent.ACTION_MAIN }
            ?: return false
        val label = name.trim().ifEmpty { default(context) }
        val info = ShortcutInfoCompat.Builder(context, SHORTCUT_ID)
            .setShortLabel(label)
            .setLongLabel(label)
            .setIcon(customIcon(context)?.let { IconCompat.createWithBitmap(it) }
                ?: IconCompat.createWithResource(context, R.mipmap.ic_launcher))
            .setIntent(launch)
            .build()
        val pinned = try {
            ShortcutManagerCompat.getShortcuts(context, ShortcutManagerCompat.FLAG_MATCH_PINNED)
                .any { it.id == SHORTCUT_ID }
        } catch (e: Exception) {
            false
        }
        if (pinned) {
            // Déjà sur l'écran d'accueil : il prend simplement le nouveau nom.
            return try { ShortcutManagerCompat.updateShortcuts(context, listOf(info)) } catch (e: Exception) { false }
        }
        if (!request || !ShortcutManagerCompat.isRequestPinShortcutSupported(context)) return false
        return try { ShortcutManagerCompat.requestPinShortcut(context, info, null) } catch (e: Exception) { false }
    }

    /** Au premier lancement d'une nouvelle version : le numéro de la version d'avant (sinon null). */
    fun justUpdated(context: Context): Int? {
        val p = prefs(context)
        val last = p.getInt("build", 0)
        val now = Updater.currentBuild
        if (last != now) p.edit().putInt("build", now).apply()
        return if (last in 1 until now) last else null
    }
}

/** Ligne des réglages « Nom de l'application ». */
@Composable
fun AppNameRow() {
    val context = LocalContext.current
    var open by remember { mutableStateOf(false) }
    var current by remember { mutableStateOf(AppName.get(context)) }
    Row(
        Modifier.fillMaxWidth().clickable { open = true }.padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(stringResource(R.string.appname_title), color = Color.White, fontSize = 16.sp)
            Text(current, color = Color.Gray, fontSize = 13.sp)
        }
    }
    if (open) AppNameDialog(onDismiss = { open = false; current = AppName.get(context) })
}

/** Après une mise à jour : nouveautés et correctifs, puis proposition de changer le nom de l'app. */
@Composable
fun AppNameAfterUpdate() {
    val context = LocalContext.current
    var news by remember { mutableStateOf<List<ChangeEntry>?>(null) }
    var editing by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        val previous = AppName.justUpdated(context) ?: return@LaunchedEffect
        val all = Changelog.bundled(context)
        news = Changelog.since(previous, all).ifEmpty { all.take(1) }
    }
    news?.let { entries ->
        WhatsNewDialog(entries, onRename = { news = null; editing = true }, onDismiss = { news = null })
    }
    if (editing) AppNameDialog(onDismiss = { editing = false })
}

@Composable
fun AppNameDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(AppName.get(context)) }
    var iconVersion by remember { mutableStateOf(0) }
    val iconPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (AppName.setCustomIcon(context, uri)) {
            iconVersion++
            AppName.pinShortcut(context, AppName.get(context), request = false)
        }
    }
    val customIcon = remember(iconVersion) { AppName.customIcon(context) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.appname_title)) },
        text = {
            Column {
                customIcon?.let {
                    Image(it.asImageBitmap(), contentDescription = null,
                        modifier = Modifier.size(72.dp).clip(RoundedCornerShape(18.dp)).align(Alignment.CenterHorizontally))
                    Spacer(Modifier.height(8.dp))
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(30) },
                    singleLine = true,
                    label = { Text(stringResource(R.string.appname_hint)) },
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(10.dp))
                TextButton(onClick = { iconPicker.launch("image/*") }) { Text(stringResource(R.string.appname_pick_icon)) }
                if (customIcon != null) {
                    TextButton(onClick = {
                        AppName.setCustomIcon(context, null)
                        iconVersion++
                        AppName.pinShortcut(context, AppName.get(context), request = false)
                    }) { Text(stringResource(R.string.appname_reset_icon)) }
                }
                Text(stringResource(R.string.appname_home_info), color = Color.Gray, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        AppName.set(context, name)
                        val ok = AppName.pinShortcut(context, AppName.get(context))
                        Toast.makeText(
                            context,
                            context.getString(if (ok) R.string.appname_done else R.string.appname_unsupported),
                            Toast.LENGTH_LONG,
                        ).show()
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(stringResource(R.string.appname_home)) }
                TextButton(onClick = { name = AppName.default(context) }) { Text(stringResource(R.string.appname_reset)) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                AppName.set(context, name)
                AppName.pinShortcut(context, AppName.get(context), request = false)
                Toast.makeText(context, context.getString(R.string.appname_done), Toast.LENGTH_SHORT).show()
                onDismiss()
            }) { Text(stringResource(R.string.appname_save)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}
