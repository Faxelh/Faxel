import AVKit
import SwiftUI
import UniformTypeIdentifiers

private enum PlayerPanel: String, Identifiable {
    case subtitles, options, episodes, translation, speed
    case watermark
    var id: String { rawValue }
}

/// Lecteur vidéo plein écran : portrait / paysage, sous-titres, vitesse,
/// pistes audio, gestes (double-toucher pour avancer, glisser pour la
/// luminosité et le volume, pincer pour remplir l'écran), verrou.
struct VideoPlayerView: View {
    @EnvironmentObject var model: AppModel
    @EnvironmentObject var video: VideoPlayerModel
    @ObservedObject private var library = MediaLibrary.shared
    let session: VideoSession

    @AppStorage("subtitleSize") private var subtitleSize = 2
    @AppStorage("subtitleBackground") private var subtitleBackground = true
    @AppStorage("videoSpeechLanguage") private var videoSpeechLanguage = "fr-FR"
    @AppStorage("subtitleTargetLanguage") private var subtitleTargetLanguage = "fr"
    @AppStorage("autoLandscape") private var autoLandscape = true

    @State private var controlsVisible = true
    @State private var hideWork: DispatchWorkItem?
    @State private var scrubbing = false
    @State private var scrubValue: Double = 0
    @State private var touchLocked = false
    @State private var rotationLocked = false
    @State private var seekFlash: (forward: Bool, amount: Int)?
    @State private var seekFlashWork: DispatchWorkItem?
    @State private var hud: (icon: String, value: Double, left: Bool)?
    @State private var scrubStart: Double = 0
    @State private var scrubPreview: Double?
    @State private var snapshotImage: UIImage?
    @State private var dragStart: CGFloat = 0
    @State private var dragKind = 0
    @State private var pinchHandled = false
    @State private var importingSubtitle = false
    @State private var noticeText: String?
    @State private var subtitleGenerationError: String?
    @State private var generatingSubtitles = false
    @State private var playerPanel: PlayerPanel?

    private static let speeds: [Float] = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 2.5]

    var body: some View {
        GeometryReader { geometry in
            let landscape = geometry.size.width > geometry.size.height
            ZStack {
                Color.black.ignoresSafeArea()
                VideoSurface(video: video, fill: video.fill)
                    .ignoresSafeArea()
                HiddenVolumeView()
                    .frame(width: 2, height: 2)
                    .allowsHitTesting(false)

                gestureLayer(size: geometry.size)

                subtitleLayer(landscape: landscape)

                if video.isBuffering && !scrubbing {
                    ProgressView()
                        .progressViewStyle(.circular)
                        .tint(.white)
                        .scaleEffect(1.4)
                        .allowsHitTesting(false)
                }

                if let flash = seekFlash {
                    seekBubble(flash.forward, flash.amount)
                        .frame(maxWidth: .infinity, alignment: flash.forward ? .trailing : .leading)
                        .padding(.horizontal, landscape ? 90 : 40)
                        .allowsHitTesting(false)
                }

                if let hud = hud {
                    hudView(hud.icon, hud.value)
                        .frame(maxWidth: .infinity, alignment: hud.left ? .leading : .trailing)
                        .padding(.horizontal, landscape ? 70 : 28)
                        .allowsHitTesting(false)
                }

                if let target = scrubPreview {
                    scrubBubble(target)
                        .allowsHitTesting(false)
                }

                if video.boosted {
                    VStack {
                        Label(L("Vitesse ×2"), systemImage: "forward.fill")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.horizontal, 14)
                            .padding(.vertical, 8)
                            .background(Capsule().fill(Color.black.opacity(0.65)))
                            .padding(.top, landscape ? 24 : 70)
                        Spacer()
                    }
                    .allowsHitTesting(false)
                }

                if showNextCard {
                    nextEpisodeCard(landscape: landscape)
                }

                if touchLocked {
                    lockedOverlay
                } else if controlsVisible {
                    controls(landscape: landscape)
                        .transition(.opacity)
                }

                if let text = noticeText {
                    VStack {
                        Text(text)
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(.white)
                            .padding(.horizontal, 14)
                            .padding(.vertical, 8)
                            .background(Capsule().fill(Color.black.opacity(0.7)))
                            .padding(.top, landscape ? 60 : 110)
                        Spacer()
                    }
                    .allowsHitTesting(false)
                    .transition(.opacity)
                }
            }
        }
        .statusBarHidden(!controlsVisible || touchLocked)
        .persistentSystemOverlays(.hidden)
        .preferredColorScheme(.dark)
        .onAppear(perform: start)
        .onChange(of: session.id) { _ in start() }
        .onDisappear(perform: finish)
        .onChange(of: video.notice) { text in
            guard let text = text else { return }
            showNotice(text)
            video.notice = nil
        }
        .onChange(of: video.isPlaying) { playing in
            if playing { scheduleHide() } else { showControls(autoHide: false) }
        }
        .onChange(of: playerPanel) { panel in
            if panel == nil {
                scheduleHide()
            } else {
                hideWork?.cancel()
                controlsVisible = true
            }
        }
        .onChange(of: video.index) { _ in
            autoRotate()
        }
        .onChange(of: library.metas[video.current?.path ?? ""]) { _ in
            autoRotate()
        }
        .sheet(item: $playerPanel) { panel in
            Group {
                switch panel {
                case .subtitles: subtitleOptionsSheet
                case .options: moreOptionsPanel
                case .episodes: episodeListPanel
                case .speed: speedOptionsPanel
                case .translation:
                    if #available(iOS 18.0, *), let subtitle = video.selectedExternal {
                        SubtitleTranslationView(sourceURL: subtitle, initialSourceLanguage: subtitleSpeechLanguageCode,
                                                initialTargetLanguage: subtitleTargetLanguage) { translated in
                            video.importSubtitle(translated)
                            try? FileManager.default.removeItem(at: translated)
                            playerPanel = nil
                            showNotice(L("Sous-titres traduits et ajoutés au lecteur."))
                        }
                    } else {
                        VStack(spacing: 12) {
                            Image(systemName: "translate").font(.system(size: 34)).foregroundStyle(Color.brand)
                            Text(L("iOS 18 requis")).font(.headline)
                            Text(L("La traduction locale des sous-titres nécessite iOS 18 ou une version ultérieure."))
                                .font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center)
                            Button(L("Fermer")) { playerPanel = nil }
                                .buttonStyle(.borderedProminent)
                        }.padding()
                    }
                case .watermark:
                    if let track = video.current { WatermarkView(track: track).environmentObject(model) }
                }
            }
            .presentationDetents([.medium, .large])
            .presentationDragIndicator(.visible)
        }
        .fileImporter(isPresented: $importingSubtitle, allowedContentTypes: subtitleTypes,
                      allowsMultipleSelection: false) { result in
            if case .success(let urls) = result, let url = urls.first {
                video.importSubtitle(url)
            }
        }
        // Les panneaux du lecteur restent ouverts pendant les gestes et le
        // défilement; fermeture uniquement via leur bouton dédié ou une action.
        .interactiveDismissDisabled(playerPanel != nil)
        .alert(L("Sous-titres"), isPresented: Binding(
            get: { subtitleGenerationError != nil },
            set: { if !$0 { subtitleGenerationError = nil } }
        )) {
            Button(L("Fermer"), role: .cancel) { subtitleGenerationError = nil }
        } message: {
            Text(subtitleGenerationError ?? "")
        }
    }

    private var subtitleTypes: [UTType] {
        var types: [UTType] = []
        if let srt = UTType(filenameExtension: "srt") { types.append(srt) }
        if let vtt = UTType(filenameExtension: "vtt") { types.append(vtt) }
        if let ass = UTType(filenameExtension: "ass") { types.append(ass) }
        if let ssa = UTType(filenameExtension: "ssa") { types.append(ssa) }
        types.append(.plainText)
        types.append(.data)
        return types
    }

    // MARK: - Ouverture / fermeture

    private func start() {
        Orientation.allow(.allButUpsideDown)
        // Retour depuis l'Image dans l'image : même file déjà en cours, on ne relance pas.
        let sameContent = video.current != nil
            && video.items.map { $0.id } == session.items.map { $0.id }
            && video.index == session.start
        if !sameContent {
            video.open(session.items, start: session.start)
        }
        autoRotate()
        scheduleHide()
    }

    private func finish() {
        // L'Image dans l'image vient de démarrer : l'écran se referme pour laisser
        // voir le reste de l'app, mais la lecture continue dans la mini-fenêtre.
        if !video.pipActive {
            video.close()
        }
        rotationLocked = false
        Orientation.allow(.portrait)
        Orientation.rotate(to: .portrait)
    }

    private func close() {
        video.close()
        model.videoSession = nil
    }

    /// Vidéo horizontale : passe en paysage (réglable).
    private func autoRotate() {
        guard autoLandscape, !rotationLocked, let track = video.current,
              let meta = library.meta(track), meta.width != nil else { return }
        if meta.isLandscape && !Orientation.isLandscape {
            Orientation.rotate(to: .landscapeRight)
        } else if !meta.isLandscape && Orientation.isLandscape {
            Orientation.rotate(to: .portrait)
        }
    }

    private func toggleRotation() {
        rotationLocked = false
        if Orientation.isLandscape {
            Orientation.allow(.allButUpsideDown)
            Orientation.rotate(to: .portrait)
        } else {
            Orientation.allow(.allButUpsideDown)
            Orientation.rotate(to: .landscapeRight)
        }
        scheduleHide()
    }

    private func toggleRotationLock() {
        rotationLocked.toggle()
        if rotationLocked {
            Orientation.lockCurrent()
            showNotice(L("Rotation verrouillée"))
        } else {
            Orientation.allow(.allButUpsideDown)
            showNotice(L("Rotation automatique"))
        }
        scheduleHide()
    }

    // MARK: - Affichage des commandes

    private func showControls(autoHide: Bool = true) {
        withAnimation(.easeOut(duration: 0.2)) { controlsVisible = true }
        if autoHide { scheduleHide() } else { hideWork?.cancel() }
    }

    private func scheduleHide() {
        hideWork?.cancel()
        guard playerPanel == nil else { return }
        let work = DispatchWorkItem {
            if video.isPlaying && !scrubbing && playerPanel == nil {
                withAnimation(.easeOut(duration: 0.3)) { controlsVisible = false }
            }
        }
        hideWork = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.5, execute: work)
    }

    private func generateSubtitles() {
        guard let track = video.current else { return }
        generatingSubtitles = true
        showControls(autoHide: false)
        showNotice(L("Génération des sous-titres sur cet iPhone…"))
        AISubtitleGenerator.generate(from: track.fileURL, localeIdentifier: videoSpeechLanguage) { result in
            generatingSubtitles = false
            switch result {
            case .success(let url):
                video.importSubtitle(url)
                try? FileManager.default.removeItem(at: url)
                showNotice(L("Sous-titres IA ajoutés à cette vidéo."))
                if #available(iOS 18.0, *), videoSpeechLanguage != subtitleTargetLanguage {
                    playerPanel = .translation
                }
            case .failure(let error):
                playerPanel = nil
                subtitleGenerationError = error.localizedDescription
            }
            scheduleHide()
        }
    }

    private func showNotice(_ text: String) {
        withAnimation { noticeText = text }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.2) {
            if noticeText == text {
                withAnimation { noticeText = nil }
            }
        }
    }

    // MARK: - Gestes

    private func gestureLayer(size: CGSize) -> some View {
        Color.clear
            .contentShape(Rectangle())
            .onTapGesture(count: 2) { location in
                guard !touchLocked else { return }
                let forward = location.x > size.width / 2
                video.skip(by: forward ? 10 : -10)
                flashSeek(forward)
            }
            .onTapGesture { _ in
                if touchLocked {
                    showControls()
                    return
                }
                if controlsVisible {
                    withAnimation(.easeOut(duration: 0.2)) { controlsVisible = false }
                } else {
                    showControls()
                }
            }
            // Appui long : vitesse ×2 tant que le doigt reste posé (comme YouTube).
            .onLongPressGesture(minimumDuration: 0.45, maximumDistance: 12, perform: {
                guard !touchLocked, video.isPlaying else { return }
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                video.setBoost(true)
            }, onPressingChanged: { pressing in
                if !pressing { video.setBoost(false) }
            })
            .gesture(
                DragGesture(minimumDistance: 14)
                    .onChanged { value in
                        guard !touchLocked else { return }
                        if dragKind == 0 {
                            let vertical = abs(value.translation.height) > abs(value.translation.width)
                            guard vertical else {
                                // Glisser à l'horizontale : avancer ou reculer dans la vidéo.
                                dragKind = 3
                                scrubStart = video.currentTime
                                showControls(autoHide: false)
                                return
                            }
                            if value.startLocation.x < size.width / 2 {
                                dragKind = 1
                                dragStart = DeviceControls.brightness
                            } else {
                                dragKind = 2
                                dragStart = CGFloat(DeviceControls.volume)
                            }
                        }
                        if dragKind == 3 {
                            let span = min(max(video.duration, 1), 180)
                            let offset = Double(value.translation.width / max(size.width, 1)) * span
                            scrubPreview = min(max(0, scrubStart + offset), max(video.duration, 0))
                            return
                        }
                        let delta = -value.translation.height / max(220, size.height * 0.6)
                        let level = min(1, max(0, dragStart + delta))
                        if dragKind == 1 {
                            DeviceControls.brightness = level
                            hud = ("sun.max.fill", Double(level), true)
                        } else if dragKind == 2 {
                            DeviceControls.volume = Float(level)
                            hud = (level == 0 ? "speaker.slash.fill" : "speaker.wave.2.fill", Double(level), false)
                        }
                    }
                    .onEnded { _ in
                        if dragKind == 2 { DeviceControls.endVolumeGesture() }
                        if dragKind == 3, let target = scrubPreview {
                            video.seek(to: target)
                            scheduleHide()
                        }
                        scrubPreview = nil
                        dragKind = 0
                        withAnimation(.easeOut(duration: 0.4).delay(0.4)) { hud = nil }
                    }
            )
            .simultaneousGesture(
                MagnificationGesture()
                    .onChanged { scale in
                        guard !touchLocked, !pinchHandled else { return }
                        if scale > 1.15 && !video.fill {
                            pinchHandled = true
                            withAnimation { video.fill = true }
                            showNotice(L("Plein écran"))
                        } else if scale < 0.87 && video.fill {
                            pinchHandled = true
                            withAnimation { video.fill = false }
                            showNotice(L("Image entière"))
                        }
                    }
                    .onEnded { _ in pinchHandled = false }
            )
    }

    private func flashSeek(_ forward: Bool) {
        let amount = (seekFlash?.forward == forward ? (seekFlash?.amount ?? 0) : 0) + 10
        withAnimation(.easeOut(duration: 0.15)) { seekFlash = (forward, amount) }
        seekFlashWork?.cancel()
        let work = DispatchWorkItem {
            withAnimation(.easeOut(duration: 0.3)) { seekFlash = nil }
        }
        seekFlashWork = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8, execute: work)
    }

    private func seekBubble(_ forward: Bool, _ amount: Int) -> some View {
        VStack(spacing: 6) {
            Image(systemName: forward ? "goforward" : "gobackward")
                .font(.system(size: 30, weight: .semibold))
            Text(forward ? "+\(amount) s" : "−\(amount) s")
                .font(.system(size: 14, weight: .bold))
        }
        .foregroundColor(.white)
        .frame(width: 110, height: 110)
        .background(Circle().fill(Color.white.opacity(0.18)))
    }

    /// Barre verticale : luminosité à gauche, volume à droite.
    private func hudView(_ icon: String, _ value: Double) -> some View {
        VStack(spacing: 10) {
            Text("\(Int(value * 100))")
                .font(.system(size: 13, weight: .bold).monospacedDigit())
            ZStack(alignment: .bottom) {
                Capsule().fill(Color.white.opacity(0.25))
                Capsule().fill(Color.white)
                    .frame(height: max(6, 150 * CGFloat(value)))
            }
            .frame(width: 8, height: 150)
            Image(systemName: icon)
                .font(.system(size: 17, weight: .semibold))
        }
        .foregroundColor(.white)
        .padding(.vertical, 14)
        .frame(width: 52)
        .background(Capsule().fill(Color.black.opacity(0.6)))
    }

    private func scrubBubble(_ target: Double) -> some View {
        let delta = target - scrubStart
        return VStack(spacing: 4) {
            Text(Fmt.clock(target))
                .font(.system(size: 30, weight: .bold).monospacedDigit())
            Text((delta >= 0 ? "+" : "−") + Fmt.clock(abs(delta)))
                .font(.system(size: 15, weight: .semibold).monospacedDigit())
                .foregroundColor(.white.opacity(0.75))
        }
        .foregroundColor(.white)
        .padding(.horizontal, 22)
        .padding(.vertical, 14)
        .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(Color.black.opacity(0.65)))
    }

    // MARK: - Épisode suivant

    private var showNextCard: Bool {
        !touchLocked && video.nextCountdown != nil
    }

    private func nextEpisodeCard(landscape: Bool) -> some View {
        let remaining = video.nextCountdown ?? 0
        let next = video.items.indices.contains(video.index + 1) ? video.items[video.index + 1] : nil
        return VStack {
            Spacer()
            HStack {
                Spacer()
                VStack(alignment: .leading, spacing: 8) {
                    Text(L("Épisode suivant dans {n} s", ["n": "\(remaining)"]))
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(.white.opacity(0.75))
                        .contentTransition(.numericText())
                        .animation(.easeInOut(duration: 0.25), value: remaining)
                    if let next = next {
                        Text(next.title)
                            .font(.system(size: 15, weight: .bold))
                            .foregroundColor(.white)
                            .lineLimit(2)
                    }
                    HStack(spacing: 10) {
                        Button {
                            video.next()
                        } label: {
                            Label(L("Lire"), systemImage: "play.fill")
                                .font(.system(size: 14, weight: .bold))
                                .foregroundColor(.black)
                                .padding(.horizontal, 14)
                                .padding(.vertical, 8)
                                .background(Capsule().fill(Color.white))
                        }
                        Button {
                            video.cancelAutoNext = true
                        } label: {
                            Text(L("Annuler"))
                                .font(.system(size: 14, weight: .semibold))
                                .foregroundColor(.white)
                                .padding(.horizontal, 14)
                                .padding(.vertical, 8)
                                .background(Capsule().fill(Color.white.opacity(0.18)))
                        }
                    }
                }
                .padding(14)
                .frame(maxWidth: 300, alignment: .leading)
                .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(Color.black.opacity(0.75)))
            }
            .padding(.horizontal, landscape ? 60 : 16)
            .padding(.bottom, landscape ? 90 : 140)
        }
        .transition(.opacity)
    }

    // MARK: - Sous-titres

    private var subtitleFont: CGFloat {
        switch subtitleSize {
        case 1: return 15
        case 3: return 24
        case 4: return 30
        default: return 19
        }
    }

    private func subtitleLayer(landscape: Bool) -> some View {
        VStack {
            Spacer()
            if let text = video.subtitleText {
                Text(text)
                    .font(.system(size: landscape ? subtitleFont + 3 : subtitleFont, weight: .semibold))
                    .foregroundColor(.white)
                    .multilineTextAlignment(.center)
                    .shadow(color: .black.opacity(0.9), radius: 2, x: 0, y: 1)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(
                        RoundedRectangle(cornerRadius: 6, style: .continuous)
                            .fill(Color.black.opacity(subtitleBackground ? 0.55 : 0))
                    )
                    .padding(.horizontal, landscape ? 60 : 16)
            }
        }
        .padding(.bottom, controlsVisible && !touchLocked ? (landscape ? 96 : 150) : (landscape ? 26 : 60))
        .animation(.easeOut(duration: 0.2), value: controlsVisible)
        .allowsHitTesting(false)
    }

    // MARK: - Commandes

    private var lockedOverlay: some View {
        VStack {
            Spacer()
            if controlsVisible {
                Button {
                    touchLocked = false
                    showControls()
                } label: {
                    Label(L("Déverrouiller l'écran"), systemImage: "lock.open.fill")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.white)
                        .padding(.horizontal, 18)
                        .padding(.vertical, 12)
                        .background(Capsule().fill(Color.white.opacity(0.22)))
                }
                .padding(.bottom, 50)
            }
        }
    }

    private func controls(landscape: Bool) -> some View {
        ZStack {
            VStack(spacing: 0) {
                LinearGradient(colors: [Color.black.opacity(0.7), .clear], startPoint: .top, endPoint: .bottom)
                    .frame(height: 140)
                Spacer()
                LinearGradient(colors: [.clear, Color.black.opacity(0.75)], startPoint: .top, endPoint: .bottom)
                    .frame(height: 200)
            }
            .ignoresSafeArea()
            .allowsHitTesting(false)

            VStack(spacing: 0) {
                topBar
                Spacer()
                centerButtons(landscape: landscape)
                Spacer()
                bottomBar
            }
            .padding(.horizontal, landscape ? 24 : 12)
            .padding(.vertical, landscape ? 8 : 4)
        }
    }

    private var topBar: some View {
        HStack(spacing: 6) {
            Button(action: close) {
                Image(systemName: "xmark")
                    .font(.system(size: 18, weight: .bold))
                    .frame(width: 44, height: 44)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(video.current.map { library.title($0) } ?? "")
                    .font(.system(size: 15, weight: .semibold))
                    .lineLimit(1)
                if video.items.count > 1 {
                    Text(L("{index} sur {count}", ["index": "\(video.index + 1)", "count": "\(video.items.count)"]))
                        .font(.system(size: 12))
                        .opacity(0.7)
                }
            }
            Spacer(minLength: 4)
            AirPlayButton(tint: .white, video: true)
                .frame(width: 40, height: 40)
            if video.pipPossible {
                Button {
                    video.togglePictureInPicture()
                } label: {
                    Image(systemName: video.pipActive ? "pip.exit" : "pip.enter")
                        .font(.system(size: 18, weight: .semibold))
                        .frame(width: 40, height: 40)
                }
            }
            if video.items.count > 1 {
                Button {
                    hideWork?.cancel()
                    playerPanel = .episodes
                } label: {
                    Image(systemName: "list.bullet")
                        .font(.system(size: 18, weight: .semibold))
                        .frame(width: 48, height: 48)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel(L("Épisodes"))
            }
            subtitleMenu
            moreMenu
        }
        .foregroundColor(.white)
    }

    private var subtitleMenu: some View {
        Button {
            hideWork?.cancel()
            playerPanel = .subtitles
            controlsVisible = true
        } label: {
            Image(systemName: video.hasSubtitles ? "captions.bubble.fill" : "captions.bubble")
                .font(.system(size: 18, weight: .semibold))
                .frame(width: 48, height: 48)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(L("Sous-titres"))
    }

    private var subtitleOptionsSheet: some View {
        NavigationStack {
            Form {
                Section(L("Sous-titres")) {
                    Button(L("Désactivés")) { video.subtitlesOff() }
                    if video.externalSubtitles.isEmpty && video.embeddedSubtitles.isEmpty {
                        Text(L("Aucun sous-titre détecté dans cette vidéo."))
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                    ForEach(video.externalSubtitles, id: \.self) { url in
                        Button(SubtitleParser.displayName(url)) { video.selectExternal(url) }
                    }
                    ForEach(video.embeddedSubtitles, id: \.self) { option in
                        Button(VideoPlayerModel.optionName(option)) { video.selectEmbedded(option) }
                    }
                    Button {
                        playerPanel = nil
                        importingSubtitle = true
                    } label: { Label(L("Charger un fichier de sous-titres…"), systemImage: "doc.badge.plus") }
                }
                Section(L("Génération IA")) {
                    Picker(L("Langue parlée : {language}", ["language": speechLanguageName]), selection: $videoSpeechLanguage) {
                        Text("Français").tag("fr-FR")
                        Text("English").tag("en-US")
                        Text("Русский").tag("ru-RU")
                        Text("Español").tag("es-ES")
                        Text("Deutsch").tag("de-DE")
                        Text("Português").tag("pt-BR")
                        Text("Italiano").tag("it-IT")
                        Text("العربية").tag("ar-SA")
                        Text("中文").tag("zh-CN")
                    }
                    Button { generateSubtitles() } label: {
                        Label(generatingSubtitles ? L("Génération des sous-titres…") : L("Générer des sous-titres avec l'IA"), systemImage: "sparkles")
                    }
                    .disabled(generatingSubtitles)
                    if generatingSubtitles {
                        ProgressView(L("Transcription audio en cours sur l’iPhone…"))
                            .font(.footnote)
                    }
                }
                Section(L("Traduction IA")) {
                    Picker(L("Traduire en"), selection: $subtitleTargetLanguage) {
                        Text("Français").tag("fr")
                        Text("English").tag("en")
                        Text("Español").tag("es")
                        Text("Русский").tag("ru")
                        Text("Deutsch").tag("de")
                        Text("Português").tag("pt")
                        Text("العربية").tag("ar")
                    }
                    if video.selectedExternal != nil {
                        Button {
                            playerPanel = .translation
                        } label: {
                            Label(L("Traduire les sous-titres en {language}…", ["language": subtitleTargetName]), systemImage: "translate")
                        }
                    } else {
                        Text(L("Chargez ou sélectionnez d’abord un fichier de sous-titres à traduire."))
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                    if #available(iOS 18.0, *), video.selectedExternal == nil {
                        Button {
                            generateSubtitles()
                        } label: {
                            Label(L("Générer puis traduire en {language}", ["language": subtitleTargetName]), systemImage: "waveform.badge.magnifyingglass")
                        }
                        .disabled(generatingSubtitles)
                        Text(L("Faxel transcrit la langue parlée choisie, puis traduit le texte des sous-titres. Cette option ne remplace pas la voix originale par une voix française."))
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                }
                Section(L("Apparence")) {
                    Picker(L("Taille du texte"), selection: $subtitleSize) {
                        ForEach([1, 2, 3, 4], id: \.self) { size in Text(sizeName(size)).tag(size) }
                    }
                    Toggle(L("Fond sombre"), isOn: $subtitleBackground)
                    if video.selectedExternal != nil {
                        HStack {
                            Text(L("Décalage : {value} s", ["value": delayText(video.subtitleDelay)]))
                            Spacer()
                            Button("−") { video.subtitleDelay -= 0.5 }
                            Button("0") { video.subtitleDelay = 0 }
                            Button("+") { video.subtitleDelay += 0.5 }
                        }
                    }
                }
            }
            .navigationTitle(L("Sous-titres"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button(L("Fermer")) { playerPanel = nil } } }
        }
    }

    private var speedOptionsPanel: some View {
        NavigationStack {
            List {
                Section(L("Vitesse de lecture")) {
                    ForEach([0.5, 1, 1.5, 2, 2.5], id: \.self) { value in
                        Button {
                            UISelectionFeedbackGenerator().selectionChanged()
                            video.setRate(Float(value))
                            playerPanel = nil
                            showControls()
                        } label: {
                            HStack {
                                Text(value == 1 ? L("Normale (1×)") : speedText(Float(value)))
                                Spacer()
                                if video.rate == Float(value) { Image(systemName: "checkmark").foregroundStyle(Color.brand) }
                            }
                            .contentShape(Rectangle())
                            .frame(minHeight: 42)
                        }
                        .buttonStyle(.plain)
                    }
                }
                Section(L("Réglage précis")) {
                    HStack {
                        Text("0,25×").font(.caption).foregroundStyle(.secondary)
                        Slider(value: Binding(
                            get: { Double(video.rate) },
                            set: { video.setRate(Float($0)) }
                        ), in: 0.25...2.5, step: 0.05)
                        .tint(.brand)
                        .accessibilityLabel(L("Vitesse de lecture"))
                        Text("2,5×").font(.caption).foregroundStyle(.secondary)
                    }
                    HStack {
                        Text(L("Vitesse actuelle"))
                        Spacer()
                        Text(speedText(video.rate)).fontWeight(.semibold).foregroundStyle(Color.brand)
                    }
                    ForEach([0.25, 0.75, 1.25, 1.75], id: \.self) { value in
                        Button {
                            video.setRate(Float(value))
                            playerPanel = nil
                            showControls()
                        } label: {
                            HStack {
                                Text(speedText(Float(value)))
                                Spacer()
                                if video.rate == Float(value) { Image(systemName: "checkmark").foregroundStyle(Color.brand) }
                            }
                            .contentShape(Rectangle())
                            .frame(minHeight: 42)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            .navigationTitle(L("Vitesse"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button(L("Fermer")) { playerPanel = nil } } }
        }
    }

    private var episodeListPanel: some View {
        NavigationStack {
            ScrollViewReader { proxy in
                List(Array(video.items.enumerated()), id: \.element.id) { index, track in
                    Button {
                        video.playEpisode(at: index)
                        playerPanel = nil
                        showControls()
                    } label: {
                        HStack(spacing: 12) {
                            Text("\(index + 1)").foregroundStyle(.secondary).frame(width: 28, alignment: .trailing)
                            VStack(alignment: .leading, spacing: 4) {
                                Text(library.title(track)).lineLimit(2)
                                Text(track.fileURL.lastPathComponent).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                            }
                            Spacer()
                            if index == video.index { Image(systemName: "waveform").foregroundStyle(Color.brand) }
                        }
                    }
                    .buttonStyle(.plain)
                    .id(index)
                }
                .onAppear { proxy.scrollTo(video.index, anchor: .center) }
                .onChange(of: video.index) { index in
                    withAnimation(.easeInOut(duration: 0.2)) { proxy.scrollTo(index, anchor: .center) }
                }
            }
            .navigationTitle(L("Épisodes"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button(L("Fermer")) { playerPanel = nil } } }
        }
    }

    private var moreOptionsPanel: some View {
        NavigationStack {
            List {
                Section(L("Vitesse")) {
                    ForEach(VideoPlayerView.speeds, id: \.self) { value in
                        Button { video.setRate(value) } label: {
                            HStack { Text(speedText(value)); Spacer(); if video.rate == value { Image(systemName: "checkmark") } }
                        }
                    }
                }
                if !video.audioOptions.isEmpty {
                    Section(L("Piste audio")) {
                        ForEach(video.audioOptions, id: \.self) { option in
                            Button { video.selectAudio(option) } label: {
                                HStack { Text(VideoPlayerModel.optionName(option)); Spacer(); if video.selectedAudio == option { Image(systemName: "checkmark") } }
                            }
                        }
                    }
                }
                Section(L("Lecture")) {
                    Button { video.repeatOne.toggle() } label: { Label(L("Répéter cette vidéo"), systemImage: video.repeatOne ? "checkmark" : "repeat.1") }
                    Button { video.setSleep(minutes: 0) } label: { Label(L("Minuterie désactivée"), systemImage: "moon.zzz") }
                    ForEach([15, 30, 45, 60, 90], id: \.self) { minutes in
                        Button(L("Arrêt dans {n} min", ["n": "\(minutes)"])) { video.setSleep(minutes: minutes) }
                    }
                    Button { withAnimation { video.fill.toggle() } } label: { Label(video.fill ? L("Image entière") : L("Remplir l'écran"), systemImage: "arrow.up.left.and.arrow.down.right") }
                    Button { toggleRotationLock() } label: { Label(rotationLocked ? L("Déverrouiller la rotation") : L("Verrouiller la rotation"), systemImage: "lock.rotation") }
                }
                Section {
                    Button { video.snapshot { image in if let image { UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil); showNotice(L("Capture enregistrée dans Photos")) } } } label: { Label(L("Capture d'écran"), systemImage: "camera") }
                    if let track = video.current {
                        Button { video.pause(); playerPanel = nil; model.compress(track) } label: { Label(L("Compresser une copie"), systemImage: "arrow.down.right.and.arrow.up.left") }
                        Button { video.pause(); playerPanel = .watermark } label: { Label(L("Retirer un filigrane…"), systemImage: "wand.and.stars") }
                        ShareLink(item: track.fileURL) { Label(L("Partager"), systemImage: "square.and.arrow.up") }
                    }
                }
            }
            .navigationTitle(L("Options du lecteur"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button(L("Fermer")) { playerPanel = nil } } }
        }
    }

    private var speechLanguageName: String {
        switch videoSpeechLanguage {
        case "fr-FR": return "Français"
        case "en-US": return "English"
        case "ru-RU": return "Русский"
        case "es-ES": return "Español"
        case "de-DE": return "Deutsch"
        case "pt-BR": return "Português"
        case "it-IT": return "Italiano"
        case "ar-SA": return "العربية"
        case "zh-CN": return "中文"
        default: return "Français"
        }
    }

    private var subtitleTargetName: String {
        switch subtitleTargetLanguage {
        case "fr": return "Français"
        case "en": return "English"
        case "es": return "Español"
        case "ru": return "Русский"
        case "de": return "Deutsch"
        case "pt": return "Português"
        case "ar": return "العربية"
        default: return "Français"
        }
    }

    private var subtitleSpeechLanguageCode: String {
        if videoSpeechLanguage == "zh-CN" { return "zh-Hans" }
        return String(videoSpeechLanguage.split(separator: "-").first ?? "fr")
    }

    private var moreMenu: some View {
        Button {
            hideWork?.cancel()
            controlsVisible = true
            playerPanel = .options
        } label: {
            Image(systemName: "ellipsis.circle")
                .font(.system(size: 19, weight: .semibold))
                .frame(width: 48, height: 48)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(L("Options du lecteur"))
    }

    private var legacyMoreMenu: some View {
        Menu {
            Menu {
                ForEach(VideoPlayerView.speeds, id: \.self) { value in
                    Button {
                        video.setRate(value)
                    } label: {
                        if video.rate == value {
                            Label(speedText(value), systemImage: "checkmark")
                        } else {
                            Text(speedText(value))
                        }
                    }
                }
            } label: {
                Label(L("Vitesse : {value}", ["value": speedText(video.rate)]), systemImage: "speedometer")
            }
            if !video.audioOptions.isEmpty {
                Menu {
                    ForEach(video.audioOptions, id: \.self) { option in
                        Button {
                            video.selectAudio(option)
                        } label: {
                            if video.selectedAudio == option {
                                Label(VideoPlayerModel.optionName(option), systemImage: "checkmark")
                            } else {
                                Text(VideoPlayerModel.optionName(option))
                            }
                        }
                    }
                } label: {
                    Label(L("Piste audio"), systemImage: "waveform")
                }
            }
            Button {
                video.repeatOne.toggle()
                showNotice(video.repeatOne ? L("Répétition de la vidéo activée") : L("Répétition désactivée"))
            } label: {
                Label(L("Répéter cette vidéo"), systemImage: video.repeatOne ? "checkmark" : "repeat.1")
            }
            Menu {
                Button(L("Désactivée")) { video.setSleep(minutes: 0) }
                Button(L("Fin de la vidéo")) {
                    video.setSleep(minutes: -1)
                    showNotice(L("Arrêt à la fin de la vidéo"))
                }
                ForEach([15, 30, 45, 60, 90], id: \.self) { minutes in
                    Button(L("{n} min", ["n": "\(minutes)"])) {
                        video.setSleep(minutes: minutes)
                        showNotice(L("Arrêt dans {n} min", ["n": "\(minutes)"]))
                    }
                }
            } label: {
                Label(sleepLabel, systemImage: "moon.zzz")
            }
            Button {
                video.snapshot { image in
                    guard let image = image else { return }
                    UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
                    showNotice(L("Capture enregistrée dans Photos"))
                }
            } label: {
                Label(L("Capture d'écran"), systemImage: "camera")
            }
            if let track = video.current {
                Button {
                    video.pause()
                    model.compress(track)
                } label: {
                    Label(L("Compresser une copie"), systemImage: "arrow.down.right.and.arrow.up.left")
                }
                Button {
                    video.pause()
                    playerPanel = .watermark
                } label: {
                    Label(L("Retirer un filigrane…"), systemImage: "wand.and.stars")
                }
            }
            Button {
                withAnimation { video.fill.toggle() }
            } label: {
                Label(video.fill ? L("Image entière") : L("Remplir l'écran"),
                      systemImage: video.fill ? "arrow.down.right.and.arrow.up.left" : "arrow.up.left.and.arrow.down.right")
            }
            Button {
                toggleRotationLock()
            } label: {
                Label(rotationLocked ? L("Déverrouiller la rotation") : L("Verrouiller la rotation"),
                      systemImage: rotationLocked ? "lock.rotation.open" : "lock.rotation")
            }
            Button {
                touchLocked = true
                controlsVisible = false
                showNotice(L("Écran verrouillé : touchez pour déverrouiller"))
            } label: {
                Label(L("Verrouiller l'écran"), systemImage: "lock.fill")
            }
            if let track = video.current {
                ShareLink(item: track.fileURL) {
                    Label(L("Partager"), systemImage: "square.and.arrow.up")
                }
            }
        } label: {
            Image(systemName: "ellipsis.circle")
                .font(.system(size: 19, weight: .semibold))
                .frame(width: 40, height: 40)
        }
        .simultaneousGesture(TapGesture().onEnded { hideWork?.cancel() })
    }

    private func centerButtons(landscape: Bool) -> some View {
        HStack(spacing: landscape ? 54 : 30) {
            if video.items.count > 1 {
                Button {
                    video.previous()
                    scheduleHide()
                } label: {
                    Image(systemName: "backward.end.fill")
                        .font(.system(size: 24))
                }
                .opacity(video.hasPrevious || video.currentTime > 5 ? 1 : 0.4)
            }
            Button {
                video.skip(by: -10)
                flashSeek(false)
                scheduleHide()
            } label: {
                Image(systemName: "gobackward.10")
                    .font(.system(size: 30, weight: .medium))
            }
            Button {
                video.toggle()
            } label: {
                Image(systemName: video.isPlaying ? "pause.fill" : "play.fill")
                    .font(.system(size: 44))
                    .frame(width: 76, height: 76)
                    .background(Circle().fill(Color.white.opacity(0.16)))
            }
            Button {
                video.skip(by: 10)
                flashSeek(true)
                scheduleHide()
            } label: {
                Image(systemName: "goforward.10")
                    .font(.system(size: 30, weight: .medium))
            }
            if video.items.count > 1 {
                Button {
                    video.next()
                    scheduleHide()
                } label: {
                    Image(systemName: "forward.end.fill")
                        .font(.system(size: 24))
                }
                .disabled(!video.hasNext)
                .opacity(video.hasNext ? 1 : 0.4)
            }
        }
        .foregroundColor(.white)
    }

    private var bottomBar: some View {
        VStack(spacing: 6) {
            HStack(spacing: 10) {
                Text(Fmt.clock(scrubbing ? scrubValue : video.currentTime))
                    .frame(minWidth: 44, alignment: .leading)
                Slider(value: Binding(
                    get: { scrubbing ? scrubValue : min(video.currentTime, max(video.duration, 1)) },
                    set: { value in
                        scrubValue = value
                        if scrubbing { video.seek(to: value) }
                    }
                ), in: 0...max(video.duration, 1), onEditingChanged: { editing in
                    if editing {
                        scrubValue = video.currentTime
                        scrubbing = true
                        hideWork?.cancel()
                    } else {
                        video.seek(to: scrubValue)
                        scrubbing = false
                        scheduleHide()
                    }
                })
                .tint(.brand)
                Text("-" + Fmt.clock(max(0, video.duration - (scrubbing ? scrubValue : video.currentTime))))
                    .frame(minWidth: 50, alignment: .trailing)
            }
            .font(.system(size: 12, weight: .semibold).monospacedDigit())
            HStack(spacing: 0) {
                barButton(Orientation.isLandscape ? "rectangle.portrait.rotate" : "rectangle.landscape.rotate",
                          L("Pivoter")) { toggleRotation() }
                Spacer()
                barButton(rotationLocked ? "lock.rotation" : "lock.rotation.open",
                          rotationLocked ? L("Verrouillée") : L("Auto"), active: rotationLocked) { toggleRotationLock() }
                Spacer()
                barButton(video.fill ? "arrow.down.right.and.arrow.up.left" : "arrow.up.left.and.arrow.down.right",
                          video.fill ? L("Remplir") : L("Ajuster")) {
                    withAnimation { video.fill.toggle() }
                    scheduleHide()
                }
                Spacer()
                Button {
                    hideWork?.cancel()
                    playerPanel = .speed
                    controlsVisible = true
                } label: {
                    barLabel("speedometer", speedText(video.rate), active: video.rate != 1)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(L("Vitesse : {value}", ["value": speedText(video.rate)]))
                Spacer()
                barButton("lock", L("Écran")) {
                    touchLocked = true
                    controlsVisible = false
                    showNotice(L("Écran verrouillé : touchez pour déverrouiller"))
                }
            }
            .padding(.horizontal, 6)
        }
        .foregroundColor(.white)
        .padding(.bottom, 6)
    }

    private func barButton(_ icon: String, _ title: String, active: Bool = false,
                           action: @escaping () -> Void) -> some View {
        Button(action: action) {
            barLabel(icon, title, active: active)
        }
    }

    private func barLabel(_ icon: String, _ title: String, active: Bool = false) -> some View {
        VStack(spacing: 3) {
            Image(systemName: icon)
                .font(.system(size: 18, weight: .semibold))
            Text(title)
                .font(.system(size: 10, weight: .semibold))
        }
        .foregroundColor(active ? .brand : .white)
        .frame(minWidth: 52, minHeight: 40)
    }

    private var sleepLabel: String {
        if video.sleepAtEnd { return L("Minuterie : fin de la vidéo") }
        if let end = video.sleepEnd {
            let minutes = max(1, Int(ceil(end.timeIntervalSinceNow / 60)))
            return L("Minuterie : {n} min", ["n": "\(minutes)"])
        }
        return L("Minuterie")
    }

    private func speedText(_ value: Float) -> String {
        let text = value == Float(Int(value)) ? "\(Int(value))" : String(format: "%g", value)
        return text.replacingOccurrences(of: ".", with: Lang.code == "fr" ? "," : ".") + "×"
    }

    private func stepLabel(_ step: Double) -> String {
        if step == 0 { return L("Remettre à zéro") }
        let sign = step > 0 ? "+" : ""
        return sign + delayText(step) + " s"
    }

    private func delayText(_ value: Double) -> String {
        let text = String(format: "%.1f", value)
        return Lang.code == "fr" ? text.replacingOccurrences(of: ".", with: ",") : text
    }

    private func sizeName(_ size: Int) -> String {
        switch size {
        case 1: return L("Petit")
        case 3: return L("Grand")
        case 4: return L("Très grand")
        default: return L("Moyen")
        }
    }
}
